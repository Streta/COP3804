/*********************************************************************
 * Author : Roosevelt Mendieta Course: Java - 2 Professor: Michael Robinson
 * Program #: 2
 * 
 * Due Date : 06/12/2019
 * 
 * 
 * Certification: I hereby certify that this work is my own and none of it is
 * the work of any other person.
 * 
 * ..........{ Roosevelt Mendieta }..........
 *********************************************************************/

public class Main {

    public static void main(String[] args) {
        mendietaRAL.theArrayList();
        mendietaRpgm2 foo = new mendietaRpgm2();

        foo.two();
    }
}